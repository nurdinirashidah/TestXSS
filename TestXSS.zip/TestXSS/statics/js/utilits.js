function writeToDom(str) {
	document.writeln(str);
}
function writelnToDom(str) {
	document.writeln(str + "<br>");
}